import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import { HttpHeaders } from "@angular/common/http";
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-view-repo-file',
  templateUrl: './view-repo-file.component.html',
  styleUrls: ['./view-repo-file.component.css']
})
export class ViewRepoFileComponent implements OnInit {

  public data :any;
  public sha:string;
  public fileSelected:string;
  public updateSuccess:boolean;
  public newSha:any;
  public commitMessage:string;

  public accessibleFiles: Array<any> = [
    { name: "webhooktriggerfile.txt", description: "Trigger File" },
    { name: "filetocreate.txt", description: "Second file" }
  ]

  constructor(private dataService: DataServiceService,private formBuilder: FormBuilder) {
      this.data=null;
      this.sha='';
      this.fileSelected = '';
      this.updateSuccess=false;
      this.commitMessage='';
   }

   viewFileForm = this.formBuilder.group({
    fileContent:'',
    commitMessage:''

  });
  

  onSubmit(): void {
    if(this.viewFileForm.value.fileContent==undefined){
      alert("ERROR - content can not be empty")
      this.viewFileForm.value.fileContent=this.data;
    }else{
      this.saveFileToGit(this.fileSelected,this.viewFileForm.value.fileContent,this.sha)
    }
    
  }

  onClickFileName(fileName:string):void{
    this.commitMessage='';
    this.getFileDataFromGit(fileName);
  }

  saveFileToGit(fileName:string, content:string, sha:string):void{
    const headers = new HttpHeaders({
      'Accept': 'application/vnd.github.v3+json',
      'Authorization':'token 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'
    });

    const body = {
        message:this.commitMessage,
        content:btoa(content),
        sha:sha
    }

    this.dataService.sendPutRequest(fileName,body,headers).subscribe((data)=> {
      this.newSha = JSON.parse(JSON.stringify(data)).content.sha;
      
      this.getFileDataFromGit(fileName)
      alert("new SHA -"+this.newSha+", old sha - "+this.sha);
      
    });
  }

  getFileDataFromGit(fileName : string):void{
    const headers = new HttpHeaders({
      'Accept': 'application/vnd.github.v3+json'
    });
    this.dataService.sendGetRequest(fileName,headers).subscribe((data) => {
      var jsonData = JSON.stringify(data);
      console.log(jsonData);
      var parsedData = JSON.parse(jsonData);
      this.data=atob(parsedData.content);
      this.sha=parsedData.sha;
      this.fileSelected=fileName;

    });
  }
  
  ngOnInit(): void {
 
  }

}
