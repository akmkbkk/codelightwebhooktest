import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse,HttpHeaders } from "@angular/common/http";

import {  throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  constructor(private httpClient: HttpClient) { }

  private REST_API_SERVER = "https://api.github.com/repos";
  private REPO_OWNER="/akmkbkk";
  private REPO_NAME="/codelightwebhooktest"
  private AUTH="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"
  private CONTENTS="/contents"
  private slash = "/";

  handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(()=> new Error(errorMessage));
  }

  public sendGetRequest(fileName:string, headers : HttpHeaders){
    const requestOptions = {headers:headers};
    return this.httpClient.get(this.REST_API_SERVER+this.REPO_OWNER+this.REPO_NAME+this.CONTENTS
      +this.slash+fileName,requestOptions).pipe(catchError(this.handleError));
  }

  public sendPutRequest(fileName:string,body:any, headers : HttpHeaders){
    const requestOptions = {headers:headers};
    return this.httpClient.put(this.REST_API_SERVER+this.REPO_OWNER+this.REPO_NAME+this.CONTENTS
      +this.slash+fileName,body,requestOptions).pipe(catchError(this.handleError));
  }
}
